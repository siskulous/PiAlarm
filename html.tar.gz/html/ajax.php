<?php
	function dbConnect(){
		$db=new SQLite3('/data/alarms.db') or die($db->lastErrorMsg());
		if(!$db){
			die($db->lastErrorMsg());
		}
		return $db;
	}
	function edit(){
		$db=dbConnect();
		if(!date_create_from_format('Y-m-d G:i:s.u',$_POST['first'])){
			die("Invalid Date");
		}
		$name=addslashes($_POST['name']);
		$query=sprintf("UPDATE schedule SET
			name='%s',
			first='%s',
			sun=%u,
			mon=%u,
			tue=%u,
			wed=%u,
			thu=%u,
			fri=%u,
			sat=%u,
			enabled=%u
			WHERE sid=%u",
			$name,
			$_POST['first'],
			intval($_POST["repeatSun"]),
			intval($_POST["repeatMon"]),
			intval($_POST["repeatTue"]),
			intval($_POST["repeatWed"]),
			intval($_POST["repeatThu"]),
			intval($_POST["repeatFri"]),
			intval($_POST["repeatSat"]),
			intval($_POST['enabled']),
			intval($_POST["sid"])
		);
		$db->exec($query) or die("Unable to execute query. $db->lastErrorMsg()");
		print("Schedule Updated");
	}

	function newSchedule(){
		$db=dbConnect();
		if(!date_create_from_format('Y-m-d G:i:s.u',$_POST['first'])){
			die ('Invalid Date');
		}
		$name=addslashes($_POST[name]);
		$query=sprintf("
			INSERT INTO schedule (
				name,
				first,
				sun,
				mon,
				tue,
				wed,
				thu,
				fri,
				sat,
				enabled
			) VALUES (
				'%s',
				'%s',
				%u,
				%u,
				%u,
				%u,
				%u,
				%u,
				%u,
				1
			)",
			$name,
			$_POST['first'],
			intval($_POST["repeatSun"]),
			intval($_POST["repeatMon"]),
			intval($_POST["repeatTue"]),
			intval($_POST["repeatWed"]),
			intval($_POST["repeatThu"]),
			intval($_POST["repeatFri"]),
			intval($_POST["repeatSat"])
		);
		$db->exec($query) or die("Unable to execute query. $db->lastErrorMsg()");
		print("New Schedule Added");
	}

	function getSchedule(){
		$db=dbConnect();
		$query="SELECT sid, name, first, sun, mon, tue, wed, thu, fri, sat, enabled FROM schedule";
		$result=$db->query($query) or die($db->lastErrorMsg());
		/*
		$return="[";
		while($row=$result->fetchArray()){
			if(strlen($return) > 1){
				$return .= ",";
			}
			$return .= '{"sid":'.$row[0].',"name":"'.$row[1].'","first":"'.$row[2].'",';
			$return .= '"sun":'.$row[3].',"mon":'.$row[4].',"tue":'.$row[5].',"wed":'.$row[6].',"thu":'.$row[7].',';
			$return .= '"fri":'.$row[8].',"sat":'.$row[9].',"enabled":'.$row[10].'}';
		}
		$return .= "]";
		*/
		$return='<table><tr><th>Name</th><th>First<br>Occurence</th>';
		$return.='<th>Repeat<br>Sunday</th>';
		$return.='<th>Repeat<br>Monday</th>';
		$return.='<th>Repeat<br>Tuesday</th>';
		$return.='<th>Repeat<br>Wednesday</th>';
		$return.='<th>Repeat<br>Thursday</th>';
		$return.='<th>Repeat<br>Friday</th>';
		$return.='<th>Repeat<br>Saturday</th><th>Enabled</th></tr>';
		while($row=$result->fetchArray()){
			$return.='<tr><td><input type="text" class="editName editField" rel="'.$row[0].'" value="'.$row[1].'"></td>';
			$return.='<td><input type="text" class="editDate editField" rel="'.$row[0].'" value="'.$row[2].'"></td>';
			$return.='<td><input type="checkbox" rel="'.$row[0].'" class="editSun editField" ';
			if($row[3] == 1){
				$return.='checked="true"';
			}
			$return.='></td>';

			$return.='<td><input type="checkbox" rel="'.$row[0].'" class="editMon editField" ';
			if($row[4] == 1){
				$return.='checked="true"';
			}
			$return.='></td>';

			$return.='<td><input type="checkbox" rel="'.$row[0].'" class="editTue editField" ';
			if($row[5] == 1){
				$return.='checked="true"';
			}
			$return.='></td>';

			$return.='<td><input type="checkbox" rel="'.$row[0].'" class="editWed editField" ';
			if($row[6] == 1){
				$return.='checked="true"';
			}
			$return.='></td>';

			$return.='<td><input type="checkbox" rel="'.$row[0].'" class="editThu editField" ';
			if($row[7] == 1){
				$return.='checked="true"';
			}
			$return.='></td>';

			$return.='<td><input type="checkbox" rel="'.$row[0].'" class="editFri editField" ';
			if($row[8] == 1){
				$return.='checked="true"';
			}
			$return.='></td>';

			$return.='<td><input type="checkbox" rel="'.$row[0].'" class="editSat editField" ';
			if($row[9] == 1){
				$return.='checked="true"';
			}
			$return.='></td>';

			$return.='<td><input type="checkbox" rel="'.$row[0].'" class="enable editField" ';
			if($row[10] == 1){
				$return.='checked="true"';
			}
			$return.='></td></tr>';

			
		}
		$return.="</table>";
		print($return);
	}

	#I created the /data directory because I don't want the db in tmp and don't want to give
	#www-data write permissions on any other base directories.
	
	

	if(isset($_POST['method'])){
		$method=$_POST['method'];
	} elseif (isset($_GET['method'])) {
		$method=$_GET['method'];
	} else {
		die("Method not defined");
	}

	switch ($method) {
		case 'new':
			newSchedule();
			break;
		case 'edit':
			edit();
			break;
		case 'getSchedule':
			getSchedule();
			break;
		
		default:
			die("Invalid method defined");
			break;
	}
?>
